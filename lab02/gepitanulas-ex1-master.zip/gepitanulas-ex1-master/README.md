# Linear Regression

## Run
1. `$ git clone https://https://github.com/magtamas/gepitanulas-ex1.git`
2. `$ cd gepitanulas-ex1`
3. `$ python .`

