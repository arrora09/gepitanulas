from ex1.src import ex1


def main():
    """
    Machine Learning Class - Exercise 1 - Linear Regression
    """
    ex1()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
